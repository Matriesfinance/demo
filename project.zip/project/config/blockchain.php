<?php

return [
    'bitcoin_confirmations' => env('BITCOIND_CONFIRMATIONS_REQUIRED', 2),
];
