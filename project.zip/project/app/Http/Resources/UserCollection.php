<?php

namespace App\Http\Resources;

class UserCollection extends ApiCollection
{
}
