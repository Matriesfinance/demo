<?php

namespace App\Http\Resources;

class MarketHistoryCollection extends ApiCollection
{
}
