<?php

namespace App\Http\Resources;

class WalletTransactionsAdminCollection extends ApiCollection
{
}
