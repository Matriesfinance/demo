import boot from './boot'
import adminRoutes from './router/admin-routes'

boot(adminRoutes);