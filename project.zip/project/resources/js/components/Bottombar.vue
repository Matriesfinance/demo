<template src="./Bottombar.htm"></template>

<script>
  export default {
    data: () => ({}),

    methods: {}
  }
</script>