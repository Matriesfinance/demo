<template>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-left">
                <p>Phone: +1494829048</p>
                <p>Email: support@exbita.com</p>
                <br />
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur aliquet diam eget risus viverra tristique. Vestibulum rutrum turpis vel tellus facilisis, a tincidunt justo lobortis. Phasellus ac eros sit amet elit imperdiet congue. Ut faucibus arcu sed enim vestibulum pretium. Mauris rutrum facilisis justo, non vestibulum libero consequat ut. Mauris mauris nisi, semper sed justo in, tincidunt posuere elit. Proin augue purus, auctor at nulla ut, dignissim viverra risus. Curabitur in tellus vel erat vehicula finibus nec et elit. Proin luctus urna vel urna tincidunt pellentesque. In in quam tincidunt, commodo felis nec, ultricies eros.
                </p>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        name: 'contact-content',
        data: () => {
            return {
                html: ''
            }
        },
        methods: {

        }
        ,
        mounted() {

        }
    }
</script>
