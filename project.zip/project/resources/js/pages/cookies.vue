<template src="./cookies.htm"></template>

<script>
    export default {
        layout: 'main',

        metaInfo() {
            return {title: this.$t('cookies')}
        },
    }
</script>
