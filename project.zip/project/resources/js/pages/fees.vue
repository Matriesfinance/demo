<template src="./fees.htm"></template>

<script>
    export default {
        layout: 'main',

        metaInfo() {
            return {title: this.$t('fees')}
        },
    }
</script>
