<template src="./terms.htm"></template>

<script>
  export default {
    layout: 'main',
    name: 'terms',
    metaInfo() {
      return {title: this.$t('terms_of_use')}
    }
  }
</script>