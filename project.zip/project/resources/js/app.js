"use strict";

import boot from './boot'

boot();